﻿using System;

class Game
{
    private Font font18;
    private Player player;
    private bool finished;
    private int lives;
    private int x;
    private int y;
    private Level currentLevel;
    private int enemies;
    private Enemy[] enemy;
    private int vulnerable;
    private Sprite playerBar, gameMenu;
    private bool keyESCPresed;


    public Game()
    {
        font18 = new Font("data/Joystix.ttf", 18);
        playerBar = new Sprite("data/playerBar.png");
        gameMenu = new Sprite("data/GameMenu.png");
        keyESCPresed = false;
        finished = false;
        player = new Player(this);
        lives = 100;
        x = player.GetX();
        y = player.GetY();
        currentLevel = new Level(player);
        enemies = 5;
        Random r = new Random();
        enemy = new Enemy[enemies];
        for (int i = 0; i < enemies; i++)
        {
            int xEnemy = r.Next(600, 2500);
            int yEnemy = r.Next(300, 400);
            enemy[i] = new Enemy(xEnemy, yEnemy, currentLevel);
        }
        vulnerable = 0;
    }


    public void Run()
    {
        while (!finished)
        {
            CheckCollisions();
            MoveElements();
            DrawElements();
            CheckKeys();
            MoveScroll();
            PauseTillNextFrame();
        }
    }


    public void DrawElements()
    {
        Hardware.ClearScreen();

        int toMoveX = player.GetX() - player.GetStartX();
        int toMoveY = player.GetY() - player.GetStartY();
        Hardware.WriteHiddenText("Lives: " + lives,
           (short)toMoveX, (short)toMoveY,
           0xCC, 0xCC, 0xCC,
           font18);
        currentLevel.DrawOnHiddenScreen();
        player.DrawOnHiddenScreen();
        if (keyESCPresed)
            gameMenu.DrawOnHiddenScreen();
        playerBar.DrawOnHiddenScreen();
        for (int i = 0; i < enemies; i++)
            enemy[i].DrawOnHiddenScreen();
        Hardware.ShowHiddenScreen();
        player.Break(currentLevel);
    }


    public void MoveElements()
    {
        player.Move();
        for (int i = 0; i < enemies; i++)
            enemy[i].Move(player);
        int toMoveX = player.GetX() - player.GetStartX();
        int toMoveY = player.GetY() - player.GetStartY();
        playerBar.SetY(toMoveY);
        playerBar.SetX(toMoveX);
        gameMenu.SetX(toMoveX + 300);
        gameMenu.SetY(toMoveY + 100);

        if (keyESCPresed)
        {
            toMoveX = player.GetX() - player.GetStartX() - 545;
            toMoveY = player.GetY() - player.GetStartY() - 433;
            int xMouse = (Mouse.GetX() + (player.GetStartX() - 545));
            int yMouse = (Mouse.GetY() + (player.GetStartY() - 433));
            if (Mouse.Clic() == 1 && 
                (x >= 27 + toMoveX && x <= 423 + toMoveX)
                && (y >= 76 + toMoveY && y <= 143 + toMoveY))
            {
                keyESCPresed = false;
            }
            else if (Mouse.Clic() == 1 &&
                (x >= 27 + toMoveX && x <= 423 + toMoveX)
                && (y >= 156 + toMoveY && y <= 223 + toMoveY))
            {
            }
            else if (Mouse.Clic() == 1 &&
                (x >= 27 + toMoveX && x <= 423 + 305)
                && (y >= 235 + toMoveY && y <= 223 + toMoveY))
            {
                Hardware.ResetScroll();
                finished = true;
            }
        }

    }


    public void MoveScroll()
    {
        int moved = player.GetX() - x;
        Hardware.ScrollHorizontally((short)-moved);
        x = player.GetX();
        moved = player.GetY() - y;
        Hardware.ScrollVertically((short)-moved);
        y = player.GetY();
    }

    public void CheckKeys()
    {
        if (Hardware.KeyPressed(Hardware.KEY_W))
        {
            if (Hardware.KeyPressed(Hardware.KEY_D))
                player.JumpRight();
            else
            if (Hardware.KeyPressed(Hardware.KEY_A))
                player.JumpLeft();
            else
                player.Jump();
        }

        else if (Hardware.KeyPressed(Hardware.KEY_D))
            player.MoveRight();

        else if (Hardware.KeyPressed(Hardware.KEY_A))
            player.MoveLeft();

        if (Hardware.KeyPressed(Hardware.KEY_ESC))
        {
            keyESCPresed = true;
        }
    }

    public bool IsValidMove(int xMin, int yMin, int xMax, int yMax)
    {
        return currentLevel.IsValidMove(xMin, yMin, xMax, yMax);
    }


    public void PauseTillNextFrame()
    {
        // Pause till next frame (20 ms = 50 fps)
        Hardware.Pause(20);
    }


    public void CheckCollisions()
    {
        for (int i = 0; i < enemies; i++)
            if (enemy[i].CollisionsWith(player))
            {
                if (vulnerable <= 0)
                {
                    lives--;
                    vulnerable = 1000;
                }
                else
                    vulnerable--;
            }
        if (lives <= 0)
            finished = true;
    }
}